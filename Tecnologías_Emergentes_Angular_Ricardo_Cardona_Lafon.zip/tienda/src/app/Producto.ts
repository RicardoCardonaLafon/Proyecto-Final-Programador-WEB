export class Producto {
    nombre : string;
    precio : string;
    unidades : string;
    url : string;
}